import { Handler } from '@netlify/functions';

// En production, on utiliserait une base de données pour stocker les codes
const verificationCodes = new Map();

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: 'Method Not Allowed'
    };
  }

  try {
    const { email, code } = JSON.parse(event.body || '{}');
    const storedData = verificationCodes.get(email);

    if (!storedData) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Code expiré ou invalide' })
      };
    }

    if (Date.now() > storedData.expiry) {
      verificationCodes.delete(email);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Code expiré' })
      };
    }

    if (storedData.code !== code) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Code incorrect' })
      };
    }

    verificationCodes.delete(email);
    return {
      statusCode: 200,
      body: JSON.stringify({ success: true })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Erreur lors de la vérification du code' })
    };
  }
};