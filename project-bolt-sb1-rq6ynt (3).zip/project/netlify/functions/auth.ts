import { Handler } from '@netlify/functions';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// En production, utilisez une vraie base de données
const users = new Map();

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const path = event.path.replace('/.netlify/functions/auth/', '');

  try {
    const { email, password, firstName, lastName, birthDate, gender } = JSON.parse(event.body || '{}');

    switch (path) {
      case 'register': {
        if (users.has(email)) {
          return {
            statusCode: 400,
            body: JSON.stringify({ error: 'Cet email est déjà utilisé' })
          };
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = {
          email,
          password: hashedPassword,
          firstName,
          lastName,
          birthDate,
          gender,
          verified: false,
          createdAt: new Date().toISOString()
        };

        users.set(email, user);
        
        const token = jwt.sign({ email }, JWT_SECRET, { expiresIn: '24h' });
        
        return {
          statusCode: 200,
          body: JSON.stringify({ token, user: { ...user, password: undefined } })
        };
      }

      case 'login': {
        const user = users.get(email);
        
        if (!user || !await bcrypt.compare(password, user.password)) {
          return {
            statusCode: 401,
            body: JSON.stringify({ error: 'Email ou mot de passe incorrect' })
          };
        }

        if (!user.verified) {
          return {
            statusCode: 403,
            body: JSON.stringify({ error: 'Compte non vérifié' })
          };
        }

        const token = jwt.sign({ email }, JWT_SECRET, { expiresIn: '24h' });
        
        return {
          statusCode: 200,
          body: JSON.stringify({ token, user: { ...user, password: undefined } })
        };
      }

      default:
        return { statusCode: 404, body: 'Not Found' };
    }
  } catch (error) {
    console.error('Auth error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Erreur interne du serveur' })
    };
  }
};