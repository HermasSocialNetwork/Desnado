import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import nodemailer from 'nodemailer';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Store verification codes temporarily (in production, use a database)
const verificationCodes = new Map();

app.post('/api/auth/send-verification', async (req, res) => {
  try {
    const { email } = req.body;
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Store the code with expiration
    verificationCodes.set(email, {
      code,
      expiry: Date.now() + 600000 // 10 minutes
    });

    await transporter.sendMail({
      from: `"Desnado" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: 'Code de vérification Desnado',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #6d28d9; text-align: center;">Desnado</h1>
          <p>Bonjour,</p>
          <p>Voici votre code de vérification pour activer votre compte Desnado :</p>
          <div style="background-color: #f3f4f6; padding: 20px; text-align: center; font-size: 24px; letter-spacing: 5px;">
            <strong>${code}</strong>
          </div>
          <p>Ce code expirera dans 10 minutes.</p>
          <p>Si vous n'avez pas demandé ce code, veuillez ignorer cet email.</p>
          <p>Cordialement,<br>L'équipe Desnado</p>
        </div>
      `
    });

    res.json({ success: true });
  } catch (error) {
    console.error('Erreur lors de l\'envoi du code:', error);
    res.status(500).json({ error: 'Erreur lors de l\'envoi du code' });
  }
});

app.post('/api/auth/verify-code', (req, res) => {
  const { email, code } = req.body;
  const storedData = verificationCodes.get(email);

  if (!storedData) {
    return res.status(400).json({ error: 'Code expiré ou invalide' });
  }

  if (Date.now() > storedData.expiry) {
    verificationCodes.delete(email);
    return res.status(400).json({ error: 'Code expiré' });
  }

  if (storedData.code !== code) {
    return res.status(400).json({ error: 'Code incorrect' });
  }

  verificationCodes.delete(email);
  res.json({ success: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Serveur démarré sur le port ${PORT}`);
});