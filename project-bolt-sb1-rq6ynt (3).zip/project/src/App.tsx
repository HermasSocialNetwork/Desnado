import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';

function App() {
  const { token } = useAuthStore();

  return (
    <Router>
      <Routes>
        <Route path="/" element={
          token ? <Home /> : <Navigate to="/login" replace />
        } />
        
        {/* Routes publiques */}
        <Route path="/login" element={
          token ? <Navigate to="/" replace /> : <Login />
        } />
        <Route path="/register" element={
          token ? <Navigate to="/" replace /> : <Register />
        } />
        
        {/* Routes protégées */}
        <Route path="/home" element={
          token ? <Home /> : <Navigate to="/login" replace />
        } />
        
        {/* Rediriger les routes inconnues */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;