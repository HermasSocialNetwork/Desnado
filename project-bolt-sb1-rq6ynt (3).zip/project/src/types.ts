export interface User {
  id: string;
  name: string;
  email: string;
  profilePicture: string;
  coverPhoto: string;
  bio: string;
  friends: string[];
  posts: Post[];
}

export interface Post {
  id: string;
  userId: string;
  content: string;
  image?: string;
  likes: string[];
  comments: Comment[];
  createdAt: string;
}

export interface Comment {
  id: string;
  userId: string;
  content: string;
  createdAt: string;
}