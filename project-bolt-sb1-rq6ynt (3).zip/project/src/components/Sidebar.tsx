import React from 'react';
import { Users, Bookmark, Calendar, Video, ShoppingBag, Heart } from 'lucide-react';

const menuItems = [
  { icon: Users, label: 'Amis' },
  { icon: Bookmark, label: 'Enregistrés' },
  { icon: Calendar, label: 'Événements' },
  { icon: Video, label: 'Vidéos' },
  { icon: ShoppingBag, label: 'Marketplace' },
  { icon: Heart, label: 'Dating' },
];

export default function Sidebar() {
  return (
    <div className="w-64 fixed left-0 top-16 h-[calc(100vh-4rem)] p-4 overflow-y-auto">
      <div className="space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.label}
            className="flex items-center space-x-3 w-full p-3 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <item.icon className="h-6 w-6 text-violet-600" />
            <span className="text-gray-700">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}