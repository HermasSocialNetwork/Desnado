import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Users, Bell, MessageCircle, Menu, Search } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="fixed top-0 w-full bg-white border-b border-gray-200 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <span className="text-2xl font-bold text-violet-600">Desnado</span>
            </Link>
            <div className="ml-4 relative">
              <input
                type="text"
                placeholder="Rechercher sur Desnado..."
                className="w-96 pl-10 pr-4 py-2 rounded-full bg-gray-100 focus:outline-none focus:ring-2 focus:ring-violet-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div className="flex space-x-4">
            <NavIcon Icon={Home} />
            <NavIcon Icon={Users} />
            <NavIcon Icon={MessageCircle} />
            <NavIcon Icon={Bell} />
          </div>

          <div className="flex items-center space-x-4">
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=250&q=80"
              alt="Profile"
              className="w-10 h-10 rounded-full cursor-pointer"
            />
            <Menu className="h-6 w-6 text-gray-600 cursor-pointer" />
          </div>
        </div>
      </div>
    </nav>
  );
}

function NavIcon({ Icon }: { Icon: React.ElementType }) {
  return (
    <div className="p-2 hover:bg-violet-50 rounded-full cursor-pointer">
      <Icon className="h-6 w-6 text-gray-600" />
    </div>
  );
}