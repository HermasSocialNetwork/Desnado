import React from 'react';
import { Heart, MessageCircle, Share2, MoreHorizontal } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { Post as PostType } from '../types';

interface PostProps {
  post: PostType;
}

export default function Post({ post }: PostProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm mb-4">
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div className="flex space-x-3">
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=250&q=80"
              alt="Profile"
              className="w-10 h-10 rounded-full"
            />
            <div>
              <h3 className="font-semibold">Desnado Kouacanou</h3>
              <p className="text-sm text-gray-500">
                {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true, locale: fr })}
              </p>
            </div>
          </div>
          <button className="text-gray-400 hover:text-gray-600">
            <MoreHorizontal className="h-6 w-6" />
          </button>
        </div>
        
        <p className="mt-3">{post.content}</p>
        
        {post.image && (
          <img
            src={post.image}
            alt="Post content"
            className="mt-3 rounded-lg w-full object-cover max-h-96"
          />
        )}

        <div className="mt-4 flex items-center justify-between text-gray-500 text-sm">
          <span>{post.likes.length} J'aime</span>
          <span>{post.comments.length} commentaires</span>
        </div>
      </div>

      <div className="border-t border-gray-100 px-4 py-2">
        <div className="flex justify-between">
          <button className="flex items-center space-x-2 text-gray-600 hover:text-violet-600">
            <Heart className="h-5 w-5" />
            <span>J'aime</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-600 hover:text-violet-600">
            <MessageCircle className="h-5 w-5" />
            <span>Commenter</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-600 hover:text-violet-600">
            <Share2 className="h-5 w-5" />
            <span>Partager</span>
          </button>
        </div>
      </div>

      <div className="border-t border-gray-100 p-4">
        <div className="flex space-x-3">
          <img
            src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=250&q=80"
            alt="Profile"
            className="w-8 h-8 rounded-full"
          />
          <input
            type="text"
            placeholder="Écrire un commentaire..."
            className="flex-grow bg-gray-100 rounded-full px-4 focus:outline-none focus:ring-2 focus:ring-violet-500"
          />
        </div>
      </div>
    </div>
  );
}