import React, { useState } from 'react';
import { Image, Video, Smile, MapPin } from 'lucide-react';

export default function CreatePost() {
  const [content, setContent] = useState('');

  return (
    <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
      <div className="flex space-x-4">
        <img
          src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=250&q=80"
          alt="Profile"
          className="w-10 h-10 rounded-full"
        />
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Quoi de neuf, Desnado ?"
          className="flex-grow resize-none rounded-lg bg-gray-100 p-3 focus:outline-none focus:ring-2 focus:ring-violet-500"
          rows={3}
        />
      </div>
      
      <div className="mt-4 flex items-center justify-between pt-4 border-t">
        <div className="flex space-x-4">
          <button className="flex items-center space-x-2 text-gray-600 hover:bg-gray-100 px-3 py-1.5 rounded-lg">
            <Image className="h-5 w-5" />
            <span>Photo</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-600 hover:bg-gray-100 px-3 py-1.5 rounded-lg">
            <Video className="h-5 w-5" />
            <span>Vidéo</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-600 hover:bg-gray-100 px-3 py-1.5 rounded-lg">
            <Smile className="h-5 w-5" />
            <span>Feeling</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-600 hover:bg-gray-100 px-3 py-1.5 rounded-lg">
            <MapPin className="h-5 w-5" />
            <span>Location</span>
          </button>
        </div>
        <button 
          className="px-4 py-2 bg-violet-600 text-white rounded-lg hover:bg-violet-700 transition-colors"
          disabled={!content.trim()}
        >
          Publier
        </button>
      </div>
    </div>
  );
}