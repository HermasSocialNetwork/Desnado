import React from 'react';

const contacts = [
  { id: 1, name: 'Desnado Kouacanou', online: true },
  { id: 2, name: 'John Doe', online: true },
  { id: 3, name: 'Jane Smith', online: false },
  { id: 4, name: 'Alice Johnson', online: true },
  { id: 5, name: 'Bob Wilson', online: false },
];

export default function RightSidebar() {
  return (
    <div className="w-80 fixed right-0 top-16 h-[calc(100vh-4rem)] p-4 overflow-y-auto">
      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-4">Sponsorisé</h2>
        <div className="bg-white rounded-lg shadow-sm p-4">
          <img
            src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            alt="Ad"
            className="w-full h-32 object-cover rounded-lg mb-2"
          />
          <h3 className="font-medium">Découvrez nos nouveautés</h3>
          <p className="text-sm text-gray-500">desnado.com</p>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold mb-4">Contacts</h2>
        <div className="space-y-2">
          {contacts.map((contact) => (
            <button
              key={contact.id}
              className="flex items-center space-x-3 w-full p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <div className="relative">
                <img
                  src={`https://images.unsplash.com/photo-${contact.id + 1535713875002}-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80`}
                  alt={contact.name}
                  className="w-8 h-8 rounded-full"
                />
                {contact.online && (
                  <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white" />
                )}
              </div>
              <span className="text-gray-700">{contact.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}