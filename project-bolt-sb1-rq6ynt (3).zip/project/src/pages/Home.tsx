import React from 'react';
import Navbar from '../components/Navbar';
import Sidebar from '../components/Sidebar';
import RightSidebar from '../components/RightSidebar';
import CreatePost from '../components/CreatePost';
import Post from '../components/Post';

const samplePosts = [
  {
    id: '1',
    userId: '1',
    content: 'Bienvenue sur Desnado ! Le nouveau réseau social qui vous connecte avec vos proches. 🚀',
    image: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80',
    likes: ['2', '3', '4'],
    comments: [
      {
        id: '1',
        userId: '2',
        content: 'Super initiative !',
        createdAt: '2024-03-10T10:00:00Z'
      }
    ],
    createdAt: '2024-03-10T09:00:00Z'
  },
  {
    id: '2',
    userId: '2',
    content: 'Le design violet est vraiment élégant ! 💜',
    likes: ['1', '3'],
    comments: [],
    createdAt: '2024-03-10T08:30:00Z'
  }
];

export default function Home() {
  return (
    <div className="bg-gray-100 min-h-screen">
      <Navbar />
      <div className="pt-16 flex">
        <Sidebar />
        <main className="flex-1 ml-64 mr-80 p-4">
          <div className="max-w-2xl mx-auto">
            <CreatePost />
            {samplePosts.map((post) => (
              <Post key={post.id} post={post} />
            ))}
          </div>
        </main>
        <RightSidebar />
      </div>
    </div>
  );
}