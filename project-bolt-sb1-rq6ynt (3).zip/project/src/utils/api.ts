import axios from 'axios';
import { useAuthStore } from '../store/authStore';

const API_URL = import.meta.env.PROD 
  ? '/.netlify/functions'
  : 'http://localhost:3000/api';

const api = axios.create({
  baseURL: API_URL
});

// Intercepteur pour ajouter le token aux requêtes
api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const auth = {
  register: async (data: any) => {
    const response = await api.post('/auth/register', data);
    return response.data;
  },

  login: async (email: string, password: string) => {
    const response = await api.post('/auth/login', { email, password });
    return response.data;
  },

  sendVerificationCode: async (email: string) => {
    const response = await api.post('/send-verification', { email });
    return response.data;
  },

  verifyCode: async (email: string, code: string) => {
    const response = await api.post('/verify-code', { email, code });
    return response.data;
  }
};

export default api;